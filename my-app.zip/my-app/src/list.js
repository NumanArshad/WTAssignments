
import React, { Component } from 'react';
function ListItem(props) {
  return <li>{props.vlue} </li>;

 
}
function List(props) {
  const listitems = props.listItem;
  const listtems = listitems.map((items) =>
  
    <ListItem  vlue={items} />
  );
  return (
    <ul>
      {listtems}
    </ul>
  );
}


export default List;