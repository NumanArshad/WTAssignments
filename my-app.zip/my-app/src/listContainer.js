import React, { Component } from 'react';
import AddForm from './add.js';
import List from './list.js';

class ListContainer extends Component {
constructor(props) {
super(props);
this.state = {list: []};
this.submitList = this.submitList.bind(this);  }
submitList(value){
    alert("value  in container"+value);
        var newArray = this.state.list;    
    newArray.push(value);
    
    console.log(value,newArray);    this.setState({list:newArray});



}
render() {

return (
<div ><AddForm submit={this.submitList} lst={this.state.list} />
<List listItem={this.state.list}/>
</div>);}}
export default ListContainer;


