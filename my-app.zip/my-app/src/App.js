import React, { Component } from 'react';
import ListContainer from './listContainer';
class App extends Component {

render() {
return (
<ListContainer/>

);
}
}
export default App;


