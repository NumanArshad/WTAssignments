import React, { Component } from 'react';
class AddForm extends React.Component {
  constructor(props) {
    super(props);
    this.state={nameC:"numan",PasswordC:"123"};
    this.state={name:"",Password:""};
    

    this.handleChange1 = this.handleChange1.bind(this);
      this.handleChange2 = this.handleChange2.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this); }
  handleChange1(event) {

  this.setState({ name: event.target.value });

 
}
  handleChange2(event) {

  this.setState({ Password: event.target.value });

 
}
  handleSubmit(event) {
if(this.state.name==this.state.nameC && this.state.Password==this.state.PasswordC){
  alert("correct");
}
    //this.props.submitList(this.state.text)
    event.preventDefault() 
   
  
}
  render() {
    return (
        <form onSubmit={this.handleSubmit} >
        <label>
          Name:
          <input type="text"  onChange={this.handleChange1} />
          Password:
            <input type="text"  onChange={this.handleChange2} />
          </label>
          <input type="submit" value="Submit" />
      </form>
    ); }}
export default AddForm;

