
import React, { Component } from 'react';


class AddForm extends React.Component {
  constructor(props) {
    super(props);
   this.state = { list: [],text:'',name:'salman'};
     
    this.handleChange = this.handleChange.bind(this)
	    //this.state={nameC:"numan",PasswordC:"usama"};
    //this.state={name:"",Password:"",nameC:"numan",PasswordC:"123"};
        this.handleChange1 = this.handleChange1.bind(this);

    this.handleSubmit = this.handleSubmit.bind(this);
   }
    /*this.handleChange1 = this.handleChange1.bind(this);
    this.handleChange2 = this.handleChange2.bind(this);
   */

  handleChange(event) {
  this.setState({ text: event.target.value });
 
}
handleChange1(event) {
  this.setState({ name: event.target.value });
 
}
/*
handleChange1(event) {
 this.setState({ name: event.target.value });
}
  handleChange2(event) {
    this.setState({ Password: event.target.value });
 }*/
  handleSubmit(event) {
  this.props.submit(this.state.name);//(this.state.name)
    //var nameC="numan",PasswordC="123";
  // if(this.state.name===this.state.nameC && this.state.Password===this.state.PasswordC){
  //     alert("correct");
  //   }
  //   else{
  //     alert("incorrect");
  //   }
    event.preventDefault(); 
}
  render() {
  
    return (
        <form onSubmit={this.handleSubmit}
         >
        <label>
          Name:
          <input type="text"  onChange={this.handleChange} /></label>
          <label>
          Password:
          <input type="text"  onChange={this.handleChange1} /></label>
         <h1>list data is {this.props.lst[0]}</h1>
          <input type="submit" value="Submit" //onSubmit={this.handleSubmit}
          />
      </form>
    ); }}
export default AddForm;

